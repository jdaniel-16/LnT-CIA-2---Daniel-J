# Countdown Timer & Notification App (Node.js)

A small Countdown Timer & Notification App built while working through
Node.js fundamentals — process/CLI, timers, debugging, callbacks,
Promises, and async/await.

## Setup

```bash
npm install
```

## Run

```bash
node countdown.js 5
```

- Pass the countdown duration in seconds as a command-line argument
  (defaults to 5 if omitted).
- While it's running, type `cancel` and press Enter to stop it early.

## Run with nodemon (auto-restart on save)

```bash
npm run dev
```

## Files

| File | Covers |
|---|---|
| `countdown.js` | Tasks 1, 2, 3, 4, 5, 6 (comment), 7, 9 — setup, Node architecture, timers module, REPL-verified helper, CLI args + stdin cancel, the intentionally-introduced-then-fixed bug, and the final setInterval/setTimeout countdown + notification |
| `countdownModule.js` | Tasks 8 & 10 — `checkTimeLeftCallback` (error-first callback) and `checkTimeLeftPromise` (Promise-based, `.then()`/`.catch()`) |
| `captures/` | Small standalone demo scripts used to capture clean, isolated terminal output for each task |

## Task 7 note

`countdown.js` contains a comment documenting a bug that was
intentionally introduced (`if (remaining = 0)` — assignment instead of
comparison) and how it was found and fixed. `captures/task7_buggy.js`
reproduces the buggy behavior on its own for reference.
