// ============================================================
// Task 8: Asynchronous Programming & Callback Functions
// ============================================================
// checkTimeLeftCallback simulates a delay with setTimeout, then calls
// back with the remaining time using the error-first callback convention.
function checkTimeLeftCallback(seconds, callback) {
  setTimeout(() => {
    if (typeof seconds !== 'number' || seconds < 0) {
      callback(new Error('Countdown duration cannot be negative'));
      return;
    }
    callback(null, seconds);
  }, 1000);
}

// ============================================================
// Task 10: JavaScript Promises — Introduction, Detail & Revisited
// ============================================================
// checkTimeLeftPromise wraps checkTimeLeftCallback in a Promise so the
// result can be handled with .then()/.catch() instead of a callback.
function checkTimeLeftPromise(seconds) {
  return new Promise((resolve, reject) => {
    checkTimeLeftCallback(seconds, (err, result) => {
      if (err) {
        reject(err);
        return;
      }
      resolve(result);
    });
  });
}

module.exports = { checkTimeLeftCallback, checkTimeLeftPromise };
