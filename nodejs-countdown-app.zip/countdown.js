// ============================================================
// Task 1: Node.js Development Setup & Running Node.js Files
// ============================================================
// Entry file for the Countdown Timer & Notification App.
// Project was created with: npm init -y
// Run with: node countdown.js

console.log('Countdown App Ready');

// ============================================================
// Task 2: Understanding How Node.js Works & Node.js Architecture
// ============================================================
// V8 is the JavaScript engine (also used in Chrome) that compiles and
// executes the JS in this file, one statement at a time, on a single
// main thread. libuv is the C library underneath Node.js that provides
// the event loop and a background thread pool. When countdown.js starts
// a setTimeout/setInterval, libuv is the one actually tracking the
// timer and the terminal's stdin stream in the background — V8 is
// free to keep running other JS (and the terminal keeps accepting
// input) while it waits, instead of the whole program freezing.
setTimeout(() => {
  console.log('[demo] 2 seconds later: this runs AFTER the line below.');
}, 2000);
console.log('[demo] This prints immediately, before the timer above fires.');

// ============================================================
// Task 3: NodeJS Resources & Working with NodeJS Examples
// ============================================================
// Reference: official Node.js documentation for the `timers` module
// https://nodejs.org/api/timers.html
// Methods used from the docs: setInterval(), clearInterval()
// (setTimeout()/clearTimeout() are also from this module, used above/below)
//
// The block below adapts the docs' setInterval() example into a basic
// countdown: log a number every second, then clearInterval() once it
// reaches zero.
let basicCount = 3;
const basicCountdown = setInterval(() => {
  console.log(`Basic countdown: ${basicCount}`);
  basicCount--;
  if (basicCount < 0) {
    clearInterval(basicCountdown);
  }
}, 1000);

// ============================================================
// Task 4: NodeJS REPL Introduction
// ============================================================
// Verified interactively in the Node REPL first:
//   > const start = new Date();
//   > const end = new Date(start.getTime() + 5000);
//   > Math.round((end - start) / 1000)
//   5
// Working snippet moved here as a reusable function.
function secondsBetween(start, end) {
  return Math.round((end - start) / 1000);
}

// ============================================================
// Task 5: Node Process Object, Command Line & Terminal I/O
// ============================================================
// Countdown duration (in seconds) is read from the command line, e.g.:
//   node countdown.js 5
const durationArg = Number(process.argv[2]);
const countdownDuration =
  Number.isFinite(durationArg) && durationArg > 0 ? durationArg : 5;

console.log(`Starting countdown for ${countdownDuration} second(s).`);

// process.stdin lets the user type "cancel" to stop the countdown early.
process.stdin.setEncoding('utf8');
process.stdin.on('data', (input) => {
  const command = input.trim().toLowerCase();
  if (command === 'cancel') {
    console.log('Received "cancel" — stopping the countdown.');
    clearInterval(mainTimer);
    clearTimeout(notificationTimer);
    console.log('Countdown cancelled by user.');
    process.exit(0);
  }
});

// ============================================================
// Task 6: Node Packages — NodeMon & Monitoring Applications
// ============================================================
// nodemon is installed as a devDependency (npm install --save-dev nodemon)
// and run with `npm run dev` (see package.json). NodeMon watches this
// file and automatically restarts `node countdown.js` whenever it is
// saved, so changes (e.g. editing the messages below) show up without
// manually stopping/restarting the process.

// ============================================================
// Task 7: Debugging Node Programs & Debugging Techniques
// ============================================================
// A bug was intentionally introduced here: `if (remaining = 0)` used the
// assignment operator `=` instead of the comparison operator `===`.
// That line silently reset `remaining` to 0 on every tick instead of
// checking it — the (falsy) assignment always skipped the clearInterval
// branch, `remaining--` then took it to -1, and it got stuck logging
// "Time remaining: -1s" forever instead of ever stopping at zero.
// It was found by setting a breakpoint on that `if` line with the VS Code
// debugger (`node --inspect` + attach) and watching `remaining` get reset
// to 0 (then -1) every tick instead of counting down normally. The fix
// was changing `=` to `===` below.

// ============================================================
// Task 9: Node Timers & Global Objects
// ============================================================
// setInterval prints the remaining seconds every second and is cleared
// with clearInterval() exactly when the countdown reaches zero. A
// separate setTimeout (scheduled for the full duration) independently
// triggers the "Time's up!" notification once the countdown ends.
let remaining = countdownDuration;
const mainTimer = setInterval(() => {
  console.log(`Time remaining: ${remaining}s`);
  if (remaining === 0) {
    // fixed: was `if (remaining = 0)` — see Task 7 note above
    clearInterval(mainTimer);
    return;
  }
  remaining--;
}, 1000);

const notificationTimer = setTimeout(() => {
  console.log('Notification: Time is up!');
}, (countdownDuration + 1) * 1000 + 50);
