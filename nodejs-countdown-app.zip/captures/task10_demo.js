const { checkTimeLeftPromise } = require('../countdownModule');

checkTimeLeftPromise(3)
  .then((result) => console.log(`Promise result: Time left = ${result}s`))
  .catch((err) => console.log('Promise error:', err.message));

checkTimeLeftPromise(-1)
  .then((result) => console.log(`Promise result: Time left = ${result}s`))
  .catch((err) => console.log('Promise error:', err.message));
