// Task 9: Node Timers & Global Objects — isolated demo
const countdownDuration = 3;
let remaining = countdownDuration;

const mainTimer = setInterval(() => {
  console.log(`Time remaining: ${remaining}s`);
  if (remaining === 0) {
    clearInterval(mainTimer);
    return;
  }
  remaining--;
}, 1000);

// separate setTimeout, independent of the interval, fires once the
// countdown has fully ended
setTimeout(() => {
  console.log('Notification: Time is up!');
}, (countdownDuration + 1) * 1000 + 50);
