// Intentionally buggy: assignment `=` instead of comparison `===`
let remaining = 3;
const timer = setInterval(() => {
  console.log(`Time remaining: ${remaining}s`);
  if (remaining = 0) {   // BUG: always resets remaining to 0, condition is falsy (0), never clears
    clearInterval(timer);
    return;
  }
  remaining--;
}, 1000);

// safety cap so this demo terminates for the screenshot capture
setTimeout(() => {
  console.log('... (loop is stuck printing "Time remaining: -1s" forever) ...');
  clearInterval(timer);
  process.exit(0);
}, 3500);
