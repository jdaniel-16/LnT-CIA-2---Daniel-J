// Task 3: NodeJS Resources & Working with NodeJS Examples — isolated demo
let basicCount = 3;
const basicCountdown = setInterval(() => {
  console.log(`Basic countdown: ${basicCount}`);
  basicCount--;
  if (basicCount < 0) {
    clearInterval(basicCountdown);
  }
}, 1000);
