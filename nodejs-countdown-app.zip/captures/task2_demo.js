// Task 2: Understanding How Node.js Works & Node.js Architecture — isolated demo
setTimeout(() => {
  console.log('[demo] 2 seconds later: this runs AFTER the line below.');
}, 2000);
console.log('[demo] This prints immediately, before the timer above fires.');
