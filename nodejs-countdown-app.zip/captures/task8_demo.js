const { checkTimeLeftCallback } = require('../countdownModule');

checkTimeLeftCallback(5, (err, result) => {
  if (err) {
    console.log('Callback error:', err.message);
    return;
  }
  console.log(`Callback result: Time left = ${result}s`);
});
