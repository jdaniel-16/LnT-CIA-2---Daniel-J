// Task 5: Node Process Object, Command Line & Terminal I/O — isolated demo
const durationArg = Number(process.argv[2]);
const countdownDuration =
  Number.isFinite(durationArg) && durationArg > 0 ? durationArg : 5;

console.log(`Starting countdown for ${countdownDuration} second(s).`);

process.stdin.setEncoding('utf8');
process.stdin.on('data', (input) => {
  const command = input.trim().toLowerCase();
  if (command === 'cancel') {
    console.log('Received "cancel" — stopping the countdown.');
    console.log('Countdown cancelled by user.');
    process.exit(0);
  }
});
